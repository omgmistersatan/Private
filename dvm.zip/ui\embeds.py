import discord
from datetime import datetime, timezone
from config import settings

class DVMEmbeds:
    @staticmethod
    def main_panel(username: str):
        embed = discord.Embed(
            title="🖥️ DVM Management Panel",
            description=f"Welcome back, **{username}**! Select one of your Docker Virtual Machines from the dropdown below to manage it.",
            color=discord.Color.blue(),
            timestamp=datetime.now(timezone.utc)
        )
        embed.set_footer(text=f"{settings.BOT_NAME} • Your Virtual Environment")
        embed.set_thumbnail(url="https://cdn-icons-png.flaticon.com/512/919/919853.png") # Docker icon
        return embed

    @staticmethod
    def control_panel(dvm_data: dict, stats: dict = None):
        status = dvm_data.get('status', 'Unknown').capitalize()
        color = discord.Color.green() if status == "Running" else discord.Color.red()
        
        embed = discord.Embed(
            title=f"Instance: {dvm_data['hostname']}",
            color=color,
            timestamp=datetime.now(timezone.utc)
        )
        
        embed.add_field(name="📌 Container Name", value=f"`{dvm_data['container_name']}`", inline=True)
        embed.add_field(name="📶 Status", value=f"**{status}**", inline=True)
        embed.add_field(name="🏠 Hostname", value=f"`{dvm_data['hostname']}`", inline=True)
        
        if stats:
            embed.add_field(name="🧠 RAM Usage", value=f"`{stats['mem_usage_mb']}MB / {stats['mem_limit_mb']}MB`", inline=True)
            embed.add_field(name="⚡ CPU Usage", value=f"`{stats['cpu_percent']}%`", inline=True)
            embed.add_field(name="🕒 Uptime", value=f"`{stats['uptime'][:19]}`", inline=True)
        else:
            embed.add_field(name="📊 Monitoring", value="*Stats currently unavailable*", inline=False)
            
        embed.set_footer(text=f"ID: {dvm_data['id']} • Last Updated")
        return embed

    @staticmethod
    def success(message: str):
        return discord.Embed(
            description=f"✅ {message}",
            color=discord.Color.green()
        )

    @staticmethod
    def error(message: str):
        return discord.Embed(
            description=f"❌ {message}",
            color=discord.Color.red()
        )

    @staticmethod
    def warning(message: str):
        return discord.Embed(
            description=f"⚠️ {message}",
            color=discord.Color.gold()
        )
