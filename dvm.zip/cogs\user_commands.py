import discord
from discord.ext import commands
from discord import app_commands
from database.db_handler import db
from ui.manage_panel import DVMControlView
from ui.embeds import DVMEmbeds
from ui.help_view import HelpView, get_help_embed
from config import settings
from modules.docker_manager import docker_mgr

class UserCommands(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="manage")
    async def manage_dvms(self, ctx):
        """Opens the DVM Control Panel."""
        user_dvms = await db.get_user_dvms(ctx.author.id)
        
        if not user_dvms:
            return await ctx.send(embed=DVMEmbeds.error("You don't have any DVMs assigned to you."))
        
        await db.get_or_create_user(ctx.author.id, ctx.author.name)
        
        # user_dvms is already a list of DVMRecord objects
        view = DVMControlView(ctx.author.id, user_dvms)
        
        embed = DVMEmbeds.main_panel(ctx.author.name)
        await ctx.send(embed=embed, view=view)

    @app_commands.command(name="manage", description="Opens the DVM Control Panel")
    async def manage_slash(self, interaction: discord.Interaction):
        """Opens the DVM Control Panel via slash command."""
        user_dvms = await db.get_user_dvms(interaction.user.id)
        
        if not user_dvms:
            return await interaction.response.send_message(embed=DVMEmbeds.error("You don't have any DVMs assigned to you."), ephemeral=True)
        
        await db.get_or_create_user(interaction.user.id, interaction.user.name)
        
        view = DVMControlView(interaction.user.id, user_dvms)
        embed = DVMEmbeds.main_panel(interaction.user.name)
        await interaction.response.send_message(embed=embed, view=view)

    @commands.command(name="sync")
    async def sync_dvms(self, ctx):
        """Manually sync/start all DVMs (Admin only)."""
        if ctx.author.id not in settings.OWNER_IDS:
            return await ctx.send("❌ Access denied.")
        
        await ctx.send("🔄 Syncing DVM states... starting all non-suspended DVMs.")
        dvms = await db.get_all_dvms()
        for dvm in dvms:
            if not dvm.suspended:
                await docker_mgr.start_container(dvm.container_name)
                await db.update_dvm_status(dvm.id, "running")
        await ctx.send("✅ Sync complete!")

    @commands.command(name="help")
    async def help_cmd(self, ctx):
        """Shows the interactive help menu."""
        embed = get_help_embed()
        view = HelpView(ctx.author)
        await ctx.send(embed=embed, view=view)

    @app_commands.command(name="help", description="Shows the interactive help menu")
    async def help_slash(self, interaction: discord.Interaction):
        """Shows the interactive help menu via slash command."""
        embed = get_help_embed()
        view = HelpView(interaction.user)
        await interaction.response.send_message(embed=embed, view=view)

async def setup(bot):
    await bot.add_cog(UserCommands(bot))
