import os
from pydantic_settings import BaseSettings, SettingsConfigDict
from typing import Optional, List

class Settings(BaseSettings):
    # Discord Bot Settings
    DISCORD_TOKEN: str
    OWNER_IDS: List[int]
    GUILD_ID: Optional[int] = None
    SERVER_IP: Optional[str] = None
    
    # Bot Identity
    BOT_NAME: str = "DVM Manager"
    
    # Docker Settings
    DVM_IMAGE_UBUNTU: str = "ubuntu:latest"
    DVM_IMAGE_ALPINE: str = "alpine:latest"
    DVM_NETWORK_NAME: str = "dvm_network"
    
    # Data Settings
    DATA_DIR: str = "data"
    STORAGE_DIR: str = "storage"
    
    # DVM Default Limits
    DEFAULT_RAM_MB: int = 512
    DEFAULT_CPU_COUNT: float = 1.0
    DEFAULT_DISK_GB: int = 10
    
    # Paths
    BASE_DIR: str = os.path.dirname(os.path.abspath(__file__))
    LOGS_DIR: str = os.path.join(BASE_DIR, "logs")
    LOG_FILE: str = os.path.join(LOGS_DIR, "dvm_manager.log")

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
