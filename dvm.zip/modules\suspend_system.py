import logging
from modules.docker_manager import docker_mgr
from database.db_handler import db

logger = logging.getLogger("dvm_manager.suspend")

class SuspendSystem:
    @staticmethod
    async def suspend_dvm(dvm_id: int, container_name: str):
        """Suspend a DVM: stop container and lock it in DB."""
        try:
            # Stop the container
            await docker_mgr.stop_container(container_name)
            # Mark as suspended in DB
            await db.set_dvm_suspension(dvm_id, True)
            await db.update_dvm_status(dvm_id, "suspended")
            return True
        except Exception as e:
            logger.error(f"Failed to suspend {container_name}: {e}")
            return False

    @staticmethod
    async def unsuspend_dvm(dvm_id: int):
        """Unsuspend a DVM: unlock in DB."""
        try:
            await db.set_dvm_suspension(dvm_id, False)
            await db.update_dvm_status(dvm_id, "stopped")
            return True
        except Exception as e:
            logger.error(f"Failed to unsuspend DVM {dvm_id}: {e}")
            return False

suspend_sys = SuspendSystem()
