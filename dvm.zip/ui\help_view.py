import discord
from config import settings

class HelpView(discord.ui.View):
    def __init__(self, user: discord.User):
        super().__init__(timeout=180)
        self.user = user

    @discord.ui.select(
        placeholder="Choose a command category...",
        options=[
            discord.SelectOption(label="User Commands", description="General commands for all users", emoji="👤"),
            discord.SelectOption(label="Admin Commands", description="Restricted commands for bot owners", emoji="🛡️"),
            discord.SelectOption(label="Resource Policies", description="DVM resource and backup rules", emoji="💾")
        ]
    )
    async def select_category(self, interaction: discord.Interaction, select: discord.ui.Select):
        if interaction.user.id != self.user.id:
            return await interaction.response.send_message("This menu is not for you.", ephemeral=True)

        category = select.values[0]
        embed = discord.Embed(color=discord.Color.blue())

        if category == "User Commands":
            embed.title = "👤 User Commands"
            embed.description = (
                "**Prefix:** `?` or `/` (for slash commands)\n\n"
                "`?manage` - Open your DVM control panel to start/stop or access SSH.\n"
                "`?help` - Shows this interactive help menu.\n"
                "`/manage` - (Slash) Opens the control panel."
            )
        elif category == "Admin Commands":
            embed.title = "🛡️ Admin Commands (Owner Only)"
            embed.description = (
                "`/create_dvm` - Start the guided DVM creation flow.\n"
                "`/delete_dvm` - Interactive flow to backup and delete a user's DVM.\n"
                "`/unsuspend_dvm` - Restore a suspended DVM.\n"
                "`/node_info` - View server CPU/RAM/Disk stats.\n"
                "`/dvm_info` - View detailed hardware stats for a specific DVM.\n"
                "`?sync` - Manually force-start all non-suspended DVMs."
            )
        elif category == "Resource Policies":
            embed.title = "💾 Resource & Backup Policies"
            embed.description = (
                "**The 95% Guard Rule:**\n"
                "If a DVM exceeds **95%** of its assigned **RAM** or **Disk** limit, the Resource Guard triggers:\n\n"
                "1. **Pause**: The container is instantly paused.\n"
                "2. **Backup**: A full `.tar` backup of the container is created.\n"
                "3. **Notification**: The owner is DMed with the notice.\n"
                "4. **Deletion**: The container is removed to protect host stability.\n\n"
                "**CPU usage** is allowed to reach 100% of assigned cores without penalty."
            )

        await interaction.response.edit_message(embed=embed, view=self)

def get_help_embed():
    embed = discord.Embed(
        title="📚 DVM Manager Help Center",
        description=(
            "Welcome to the **DVM Manager** help menu.\n\n"
            "Use the dropdown menu below to explore different command categories and system policies.\n\n"
            "**Important:** Remote SSH access uses **tmate**. Links are generated on-demand and sent to your DMs."
        ),
        color=discord.Color.blue()
    )
    embed.set_footer(text="Shadow Clouds Infrastructure", icon_url=None)
    return embed
