import discord
from discord import app_commands
from discord.ext import commands
from typing import Optional
import logging
import psutil
from config import settings
from database.db_handler import db
from modules.docker_manager import docker_mgr
from modules.suspend_system import suspend_sys
from ui.embeds import DVMEmbeds
from ui.creation_flow import DVMCreationView
from ui.suspension_view import SuspensionView

logger = logging.getLogger("dvm_manager.admin")

def is_owner():
    async def predicate(interaction: discord.Interaction) -> bool:
        if interaction.user.id in settings.OWNER_IDS:
            return True
        await interaction.response.send_message("❌ This command is restricted to the bot owner.", ephemeral=True)
        return False
    return app_commands.check(predicate)

class AdminCommands(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    # --- DVM Creation & Deletion ---
    
    @app_commands.command(name="create_dvm", description="Start the guided DVM creation flow")
    @is_owner()
    async def create_dvm_cmd(self, interaction: discord.Interaction):
        view = DVMCreationView(interaction.user.id)
        embed = discord.Embed(
            title="DVM Creation - Step 1 of 6",
            description="Please select the owner of the new DVM.\n\n**Progress:**\n*Starting...*",
            color=discord.Color.blue()
        )
        await interaction.response.send_message(embed=embed, view=view)

    # --- Management & Status ---

    @app_commands.command(name="list_dvms", description="List all DVMs on the system")
    @is_owner()
    async def list_dvms(self, interaction: discord.Interaction):
        await interaction.response.defer()
        dvms = await db.get_all_dvms()
        
        if not dvms:
            return await interaction.followup.send("No DVMs found.")
        
        embed = discord.Embed(title="📋 All DVMs", color=discord.Color.blue())
        for dvm in dvms:
            # Fetch real status from Docker
            try:
                container = await docker_mgr.get_container(dvm.container_name)
                real_status = container.status
            except Exception:
                real_status = "offline"

            embed.add_field(
                name=f"ID: {dvm.id} | {dvm.hostname}", 
                value=f"Owner: <@{dvm.owner_discord_id}>\nStatus: `{real_status}`", 
                inline=False
            )
        await interaction.followup.send(embed=embed)

    @app_commands.command(name="dvm_info", description="Get detailed info for a specific DVM")
    @is_owner()
    async def dvm_info(self, interaction: discord.Interaction, dvm_id: int):
        await interaction.response.defer()
        dvm = await db.get_dvm_by_id(dvm_id)
        
        if not dvm:
            return await interaction.followup.send(embed=DVMEmbeds.error(f"DVM `{dvm_id}` not found."))
        
        stats = await docker_mgr.get_container_stats(dvm.container_name)
        embed = DVMEmbeds.control_panel(dvm.model_dump(), stats)
        embed.description = f"Owner: <@{dvm.owner_discord_id}>\nCreated: {dvm.created_at}"
        await interaction.followup.send(embed=embed)

    @app_commands.command(name="node_info", description="Get host machine resource usage")
    @is_owner()
    async def node_info(self, interaction: discord.Interaction):
        cpu = psutil.cpu_percent()
        ram = psutil.virtual_memory().percent
        disk = psutil.disk_usage('/').percent
        
        embed = discord.Embed(title="💾 Node Status", color=discord.Color.blue())
        embed.add_field(name="CPU Usage", value=f"`{cpu}%`", inline=True)
        embed.add_field(name="RAM Usage", value=f"`{ram}%`", inline=True)
        embed.add_field(name="Disk Usage", value=f"`{disk}%`", inline=True)
        await interaction.response.send_message(embed=embed)

    # --- Power & Maintenance ---

    @app_commands.command(name="start_dvm", description="Start a DVM")
    @is_owner()
    async def start_dvm(self, interaction: discord.Interaction, dvm_id: int):
        await interaction.response.defer()
        dvm = await db.get_dvm_by_id(dvm_id)
        if dvm:
            success = await docker_mgr.start_container(dvm.container_name)
            if success:
                await db.update_dvm_status(dvm_id, "running")
                await interaction.followup.send(embed=DVMEmbeds.success(f"Started `{dvm.hostname}`"))
            else:
                await interaction.followup.send(embed=DVMEmbeds.error("Failed to start container."))

    @app_commands.command(name="stop_dvm", description="Stop a DVM")
    @is_owner()
    async def stop_dvm(self, interaction: discord.Interaction, dvm_id: int):
        await interaction.response.defer()
        dvm = await db.get_dvm_by_id(dvm_id)
        if dvm:
            success = await docker_mgr.stop_container(dvm.container_name)
            if success:
                await db.update_dvm_status(dvm_id, "stopped")
                await interaction.followup.send(embed=DVMEmbeds.success(f"Stopped `{dvm.hostname}`"))
            else:
                await interaction.followup.send(embed=DVMEmbeds.error("Failed to stop container."))

    @app_commands.command(name="delete_dvm", description="Interactive backup & delete of a user's DVM")
    @is_owner()
    async def delete_dvm_cmd(self, interaction: discord.Interaction, target_user: discord.User):
        """Interactive flow to backup and delete a user's DVM by selecting the owner."""
        dvms = await db.get_user_dvms(target_user.id)
        if not dvms:
            return await interaction.response.send_message(f"❌ User <@{target_user.id}> has no active DVMs.", ephemeral=True)

        embed = discord.Embed(
            title="🗑️ Permanent DVM Deletion",
            description=f"User <@{target_user.id}> has **{len(dvms)}** active DVMs. Select one to perform a mandatory backup and permanent removal.",
            color=discord.Color.red()
        )
        
        view = SuspensionView(interaction, target_user, dvms)
        await interaction.response.send_message(embed=embed, view=view)

    # Note: suspend_dvm is now merged into delete_dvm flow as per user request for "by user" ops.

    @app_commands.command(name="unsuspend_dvm", description="Unsuspend a user's DVM")
    @is_owner()
    async def unsuspend_dvm(self, interaction: discord.Interaction, dvm_id: int):
        await interaction.response.defer()
        success = await suspend_sys.unsuspend_dvm(dvm_id)
        if success:
            await interaction.followup.send(embed=DVMEmbeds.success(f"DVM `{dvm_id}` has been unsuspended."))

async def setup(bot):
    await bot.add_cog(AdminCommands(bot))
