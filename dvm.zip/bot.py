import discord
from discord.ext import commands, tasks
import asyncio
import logging
import os
import sys
from datetime import datetime, timezone
from config import settings
from database.db_handler import db
from modules.docker_manager import docker_mgr
from ui.manage_panel import DVMControlView
from ui.embeds import DVMEmbeds

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
    handlers=[
        logging.FileHandler(settings.LOG_FILE),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger("dvm_manager.core")

from core.resource_guard import start_guard

class DVMManagerBot(commands.Bot):
    def __init__(self):
        super().__init__(
            command_prefix="?",
            intents=discord.Intents.all(),
            help_command=None
        )
        self.start_time = datetime.now(timezone.utc)

    async def setup_hook(self):
        # 1. Initialize Database
        await db.initialize()
        
        # 2. Load Cogs
        for filename in os.listdir('./cogs'):
            if filename.endswith('.py'):
                await self.load_extension(f'cogs.{filename[:-3]}')
        
        # 3. Sync Slash Commands
        try:
            # If GUILD_ID is provided, sync to guild for faster development
            if settings.GUILD_ID:
                guild = discord.Object(id=settings.GUILD_ID)
                self.tree.copy_global_to(guild=guild)
                await self.tree.sync(guild=guild)
            else:
                await self.tree.sync()
            logger.info("Slash commands synced.")
        except Exception as e:
            logger.error(f"Failed to sync slash commands: {e}")

        # 4. Start Resource Guard (Replaces old monitor)
        self.loop.create_task(start_guard(self))

    async def on_ready(self):
        logger.info(f"Bot logged in as {self.user} (ID: {self.user.id})")
        logger.info(f"Connected to {len(self.guilds)} guilds.")
        
        # Start all DVMs on boot
        logger.info("Starting all DVMs on bot boot...")
        dvms = await db.get_all_dvms()
        
        async def start_task(dvm):
            if not dvm.suspended:
                await docker_mgr.start_container(dvm.container_name)
                await db.update_dvm_status(dvm.id, "running")
                logger.info(f"Boot: Started DVM {dvm.hostname}")

        if dvms:
            await asyncio.gather(*(start_task(dvm) for dvm in dvms))
        logger.info("All DVMs processed.")

    async def close(self):
        """Stop all DVMs when the bot goes offline."""
        logger.info("Bot is shutting down. Stopping all DVMs...")
        dvms = await db.get_all_dvms()
        
        async def stop_task(dvm):
            # Fast stop (3s) for shutdown flow
            await docker_mgr.stop_container(dvm.container_name, timeout=3)
            await db.update_dvm_status(dvm.id, "stopped")
            logger.info(f"Shutdown: Stopped DVM {dvm.hostname}")

        if dvms:
            # Parallel stop (limited by docker_mgr semaphore)
            await asyncio.gather(*(stop_task(dvm) for dvm in dvms))
        
        await super().close()
        logger.info("All DVMs stopped. Bot process ended.")

bot = DVMManagerBot()

if __name__ == "__main__":
    bot.run(settings.DISCORD_TOKEN)
