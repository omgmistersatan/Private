import json
import os
import asyncio
import logging
from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field
from datetime import datetime, timezone
from config import settings

logger = logging.getLogger("dvm_manager.db")

class UserRecord(BaseModel):
    discord_id: int
    username: str
    created_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

class DVMRecord(BaseModel):
    id: int
    owner_discord_id: int
    container_name: str
    hostname: str
    ram_limit_mb: int
    cpu_limit: float
    disk_limit_gb: int
    status: str = "stopped"
    created_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    suspended: bool = False
    image: str
    ssh_port: Optional[int] = None
    root_password: str = "rootpass"

class PortRecord(BaseModel):
    dvm_id: int
    port_number: int
    protocol: str = "tcp"
    host_port: Optional[int] = None

class JSONDatabase:
    def __init__(self):
        self.data_dir = os.path.join(settings.BASE_DIR, "data")
        self.users_file = os.path.join(self.data_dir, "users.json")
        self.dvms_file = os.path.join(self.data_dir, "dvms.json")
        self.lock = asyncio.Lock()
        
        if not os.path.exists(self.data_dir):
            os.makedirs(self.data_dir)

        # Initialize files if they don't exist
        for f in [self.users_file, self.dvms_file]:
            if not os.path.exists(f):
                with open(f, 'w') as f_out:
                    json.dump([], f_out)

    async def _read(self, file_path: str) -> List[Dict]:
        async with self.lock:
            try:
                if not os.path.exists(file_path):
                    return []
                with open(file_path, 'r') as f:
                    return json.load(f)
            except Exception as e:
                logger.error(f"Error reading {file_path}: {e}")
                return []

    async def _write(self, file_path: str, data: List[Dict]):
        async with self.lock:
            try:
                with open(file_path, 'w') as f:
                    json.dump(data, f, indent=4)
            except Exception as e:
                logger.error(f"Error writing to {file_path}: {e}")

    # User CRUD
    async def get_or_create_user(self, discord_id: int, username: str) -> UserRecord:
        users = await self._read(self.users_file)
        for u in users:
            if u['discord_id'] == discord_id:
                return UserRecord(**u)
        
        new_user = UserRecord(discord_id=discord_id, username=username)
        users.append(new_user.model_dump())
        await self._write(self.users_file, users)
        return new_user

    # DVM CRUD
    async def create_dvm(self, owner_id: int, container_name: str, hostname: str, ram: int, cpu: float, disk: int, image: str, ssh_port: int, root_password: str = "rootpass") -> DVMRecord:
        dvms = await self._read(self.dvms_file)
        new_id = max([d['id'] for d in dvms], default=0) + 1
        
        new_dvm = DVMRecord(
            id=new_id,
            owner_discord_id=owner_id,
            container_name=container_name,
            hostname=hostname,
            ram_limit_mb=ram,
            cpu_limit=cpu,
            disk_limit_gb=disk,
            image=image,
            ssh_port=ssh_port,
            root_password=root_password,
            status="running"
        )
        dvms.append(new_dvm.model_dump())
        await self._write(self.dvms_file, dvms)
        return new_dvm

    async def get_dvm_by_name(self, container_name: str) -> Optional[DVMRecord]:
        dvms = await self._read(self.dvms_file)
        for d in dvms:
            if d['container_name'] == container_name:
                return DVMRecord(**d)
        return None

    async def get_dvm_by_id(self, dvm_id: int) -> Optional[DVMRecord]:
        dvms = await self._read(self.dvms_file)
        for d in dvms:
            if d['id'] == dvm_id:
                return DVMRecord(**d)
        return None

    async def get_user_dvms(self, discord_id: int) -> List[DVMRecord]:
        dvms = await self._read(self.dvms_file)
        return [DVMRecord(**d) for d in dvms if d['owner_discord_id'] == discord_id]

    async def get_all_dvms(self) -> List[DVMRecord]:
        dvms = await self._read(self.dvms_file)
        return [DVMRecord(**d) for d in dvms]

    async def update_dvm_status(self, dvm_id: int, status: str):
        dvms = await self._read(self.dvms_file)
        for d in dvms:
            if d['id'] == dvm_id:
                d['status'] = status
                break
        await self._write(self.dvms_file, dvms)

    async def set_dvm_suspension(self, dvm_id: int, suspended: bool):
        dvms = await self._read(self.dvms_file)
        for d in dvms:
            if d['id'] == dvm_id:
                d['suspended'] = suspended
                d['status'] = "suspended" if suspended else "stopped"
                break
        await self._write(self.dvms_file, dvms)

    async def delete_dvm(self, dvm_id: int):
        dvms = await self._read(self.dvms_file)
        dvms = [d for d in dvms if d['id'] != dvm_id]
        await self._write(self.dvms_file, dvms)

    # Simplified initialize for bot.py compatibility
    async def initialize(self):
        logger.info("JSON Database initialized.")

db = JSONDatabase()
