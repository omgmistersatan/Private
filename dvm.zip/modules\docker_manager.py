import docker
import logging
import os
import asyncio
from typing import Dict, Any, Optional, List
from config import settings

logger = logging.getLogger("dvm_manager.docker")

class DockerManager:
    def __init__(self):
        try:
            self.client = docker.from_env()
            self.ensure_network()
            # Semaphore to limit concurrent Docker operations (Scalability requirement)
            self.operation_semaphore = asyncio.Semaphore(5)
        except Exception as e:
            logger.error(f"Failed to connect to Docker daemon: {e}")
            self.client = None

    def ensure_network(self):
        """Ensure the DVM bridge network exists."""
        try:
            networks = self.client.networks.list(names=[settings.DVM_NETWORK_NAME])
            if not networks:
                self.client.networks.create(
                    settings.DVM_NETWORK_NAME,
                    driver="bridge",
                    check_duplicate=True
                )
                logger.info(f"Created bridge network: {settings.DVM_NETWORK_NAME}")
        except Exception as e:
            logger.error(f"Error ensuring network: {e}")

    async def create_container(
        self, 
        name: str, 
        hostname: str, 
        image: str = "ubuntu:latest",
        ram_mb: int = 512,
        cpu_count: float = 1.0,
        ports: Dict[str, Any] = None
    ) -> Optional[docker.models.containers.Container]:
        """Create and start a new DVM container with persistent storage."""
        if not self.client:
            return None

        async with self.operation_semaphore:
            try:
                # 1. Pull image if not exists (Non-blocking)
                try:
                    await asyncio.to_thread(self.client.images.get, image)
                except docker.errors.ImageNotFound:
                    logger.info(f"Pulling image {image}... This may take a while.")
                    await asyncio.to_thread(self.client.images.pull, image)
    
                # 2. Setup Persistent Storage
                storage_path = os.path.join(settings.BASE_DIR, "storage", name)
                if not os.path.exists(storage_path):
                    await asyncio.to_thread(os.makedirs, storage_path)
    
                # Convert RAM to bytes
                mem_limit = f"{ram_mb}m"
                # CPU count to nano_cpus
                nano_cpus = int(cpu_count * 1_000_000_000)
    
                # Mount /root inside the container
                volumes = {
                    storage_path: {'bind': '/root', 'mode': 'rw'}
                }
    
                # 3. Run container (Non-blocking)
                # Note: No command here to allow default entrypoint/CMD (like sshd)
                container = await asyncio.to_thread(
                    self.client.containers.run,
                    image=image,
                    name=name,
                    hostname=hostname,
                    mem_limit=mem_limit,
                    nano_cpus=nano_cpus,
                    network=settings.DVM_NETWORK_NAME,
                    ports=ports,
                    volumes=volumes,
                    detach=True,
                    tty=True,
                    stdin_open=True,
                    restart_policy={"Name": "unless-stopped"}
                )
                logger.info(f"Container {name} created successfully with storage at {storage_path}")
                return container
            except Exception as e:
                logger.error(f"Failed to create container {name}: {e}")
                return None

    async def get_container(self, name: str):
        return await asyncio.to_thread(self.client.containers.get, name)

    async def stop_container(self, name: str, timeout: int = 10):
        try:
            async with self.operation_semaphore:
                container = await self.get_container(name)
                await asyncio.to_thread(container.stop, timeout=timeout)
            return True
        except Exception as e:
            logger.error(f"Failed to stop container {name}: {e}")
            return False

    async def start_container(self, name: str):
        try:
            async with self.operation_semaphore:
                container = await self.get_container(name)
                await asyncio.to_thread(container.start)
            return True
        except Exception as e:
            logger.error(f"Failed to start container {name}: {e}")
            return False

    async def restart_container(self, name: str):
        try:
            container = await self.get_container(name)
            await asyncio.to_thread(container.restart)
            return True
        except Exception as e:
            logger.error(f"Failed to restart container {name}: {e}")
            return False

    async def remove_container(self, name: str):
        try:
            async with self.operation_semaphore:
                container = await self.get_container(name)
                await asyncio.to_thread(container.remove, force=True)
            return True
        except Exception as e:
            logger.error(f"Failed to remove container {name}: {e}")
            return False

    async def get_container_stats(self, name: str) -> Dict[str, Any]:
        """Fetch real-time stats for a container (Non-blocking)."""
        try:
            container = await self.get_container(name)
            stats = await asyncio.to_thread(container.stats, stream=False)
            
            # Simple parsing of stats with safety checks for Windows/WSL2
            cpu_stats = stats.get('cpu_stats', {})
            precpu_stats = stats.get('precpu_stats', {})
            
            cpu_usage = cpu_stats.get('cpu_usage', {}).get('total_usage', 0)
            precpu_usage = precpu_stats.get('cpu_usage', {}).get('total_usage', 0)
            
            # Windows/WSL2 sometimes uses different keys or omits system_cpu_usage
            system_cpu_usage = cpu_stats.get('system_cpu_usage', 0)
            pre_system_cpu_usage = precpu_stats.get('system_cpu_usage', 0)
            
            cpu_delta = cpu_usage - precpu_usage
            system_delta = system_cpu_usage - pre_system_cpu_usage
            
            cpu_percent = 0.0
            # Fallback for CPU calculation if system_cpu_usage is missing
            if system_delta > 0:
                # Standard Linux way
                core_count = cpu_stats.get('online_cpus', len(cpu_stats.get('cpu_usage', {}).get('percpu_usage', [1])))
                cpu_percent = (cpu_delta / system_delta) * core_count * 100.0
            else:
                # Alternative for environments without system_cpu_usage (e.g. some Windows setups)
                # We can't easily calculate % without system delta, so we might just report 0 or simplified usage
                cpu_percent = 0.0

            # Memory stats
            mem_stats = stats.get('memory_stats', {})
            mem_usage = mem_stats.get('usage', 0) / (1024 * 1024) # MB
            mem_limit = mem_stats.get('limit', 0) / (1024 * 1024) # MB
            
            return {
                "cpu_percent": round(cpu_percent, 2),
                "mem_usage_mb": round(mem_usage, 2),
                "mem_limit_mb": round(mem_limit, 2),
                "status": container.status,
                "uptime": stats.get('read', 'unknown')
            }
        except Exception as e:
            logger.error(f"Failed to get stats for {name}: {e}")
            return {}

    async def execute_command(self, name: str, cmd: str):
        """Execute a command inside the container and return (exit_code, output)."""
        try:
            async with self.operation_semaphore:
                container = await self.get_container(name)
                
                # Safety: If container is paused, we MUST unpause to exec
                # Docker stats include state
                if container.status == 'paused':
                    logger.info(f"[Docker] Unpausing {name} for command execution...")
                    await asyncio.to_thread(container.unpause)

                # exec_run returns (exit_code, output)
                result = await asyncio.to_thread(container.exec_run, cmd)
                exit_code = result[0]
                output = result[1].decode('utf-8', errors='replace')
                return exit_code, output
        except Exception as e:
            logger.error(f"Exec failed in {name}: {e}")
            return -1, str(e)

    async def pause_container(self, name: str):
        try:
            async with self.operation_semaphore:
                container = await self.get_container(name)
                await asyncio.to_thread(container.pause)
            return True
        except Exception as e:
            logger.error(f"Failed to pause {name}: {e}")
            return False

    async def unpause_container(self, name: str):
        try:
            async with self.operation_semaphore:
                container = await self.get_container(name)
                await asyncio.to_thread(container.unpause)
            return True
        except Exception as e:
            logger.error(f"Failed to unpause {name}: {e}")
            return False

    async def export_container(self, name: str, output_path: str):
        """Export container as a tar archive for backup."""
        try:
            async with self.operation_semaphore:
                container = await self.get_container(name)
                generator = await asyncio.to_thread(container.export)
                
                # Write generator to file in a thread-safe way
                def _write_backup():
                    with open(output_path, 'wb') as f:
                        for chunk in generator:
                            f.write(chunk)
                
                await asyncio.to_thread(_write_backup)
            return True
        except Exception as e:
            logger.error(f"Backup failed for {name}: {e}")
            return False

    async def get_disk_usage(self, name: str):
        """Estimate disk usage of the /root volume inside container."""
        code, output = await self.execute_command(name, "df -B1 /root | tail -n 1 | awk '{print $3}'")
        if code == 0 and output.strip().isdigit():
            return int(output.strip())
        return 0

docker_mgr = DockerManager()
