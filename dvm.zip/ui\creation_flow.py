import discord
import json
import os
from typing import Dict, Any, Optional
from modules.docker_manager import docker_mgr
from modules.ssh_manager import ssh_mgr
from database.db_handler import db
from ui.embeds import DVMEmbeds
from config import settings
import logging

logger = logging.getLogger("dvm_manager.ui")

class HostnameModal(discord.ui.Modal, title="DVM Hostname"):
    hostname = discord.ui.TextInput(
        label="Hostname",
        placeholder="e.g. minecraft-server",
        min_length=3,
        max_length=20
    )

    def __init__(self, parent_view):
        super().__init__()
        self.parent_view = parent_view

    async def on_submit(self, interaction: discord.Interaction):
        self.parent_view.data['hostname'] = self.hostname.value
        await self.parent_view.next_step(interaction)

class DiskModal(discord.ui.Modal, title="Disk Size"):
    disk = discord.ui.TextInput(
        label="Disk Size (GB)",
        placeholder="e.g. 10",
        min_length=1,
        max_length=3
    )

    def __init__(self, parent_view):
        super().__init__()
        self.parent_view = parent_view

    async def on_submit(self, interaction: discord.Interaction):
        try:
            val = int(self.disk.value)
            self.parent_view.data['disk'] = val
            await self.parent_view.next_step(interaction)
        except ValueError:
            await interaction.response.send_message("Invalid disk size. Please enter a number.", ephemeral=True)

class DVMCreationView(discord.ui.View):
    def __init__(self, owner_id: int):
        super().__init__(timeout=600)
        self.owner_id = owner_id
        self.step = 1
        self.data = {
            'user': None,
            'hostname': None,
            'ram': None,
            'cpu': None,
            'disk': None,
            'os': None,
            'image': None
        }
        self.templates = self._load_templates()
        self._setup_step()

    def _load_templates(self) -> Dict[str, str]:
        path = os.path.join(settings.BASE_DIR, "templates.json")
        if os.path.exists(path):
            with open(path, 'r') as f:
                return json.load(f)
        return {"alpine": "alpine:latest"}

    def _setup_step(self):
        self.clear_items()
        if self.step == 1:
            # Step 1: Select User
            user_select = discord.ui.UserSelect(placeholder="Select the DVM owner...")
            user_select.callback = self.user_select_callback
            self.add_item(user_select)
        elif self.step == 2:
            # Step 2: Hostname (handled via button to show modal)
            btn = discord.ui.Button(label="Enter Hostname", style=discord.ButtonStyle.primary)
            btn.callback = self.hostname_btn_callback
            self.add_item(btn)
        elif self.step == 3:
            # Step 3: Select RAM
            options = [
                discord.SelectOption(label="512MB", value="512"),
                discord.SelectOption(label="1GB", value="1024"),
                discord.SelectOption(label="2GB", value="2048"),
                discord.SelectOption(label="4GB", value="4096"),
                discord.SelectOption(label="8GB", value="8192")
            ]
            ram_select = discord.ui.Select(placeholder="Select RAM limit...", options=options)
            ram_select.callback = self.ram_select_callback
            self.add_item(ram_select)
        elif self.step == 4:
            # Step 4: Select CPU
            options = [
                discord.SelectOption(label="1 Core", value="1.0"),
                discord.SelectOption(label="2 Cores", value="2.0"),
                discord.SelectOption(label="4 Cores", value="4.0"),
                discord.SelectOption(label="8 Cores", value="8.0")
            ]
            cpu_select = discord.ui.Select(placeholder="Select CPU cores...", options=options)
            cpu_select.callback = self.cpu_select_callback
            self.add_item(cpu_select)
        elif self.step == 5:
            # Step 5: Disk Size
            btn = discord.ui.Button(label="Enter Disk Size", style=discord.ButtonStyle.primary)
            btn.callback = self.disk_btn_callback
            self.add_item(btn)
        elif self.step == 6:
            # Step 6: Select OS
            options = [
                discord.SelectOption(label=name.replace("ubuntu", "Ubuntu ").replace("debian", "Debian ").capitalize(), value=name)
                for name in self.templates.keys()
            ]
            os_select = discord.ui.Select(placeholder="Select Operating System...", options=options)
            os_select.callback = self.os_select_callback
            self.add_item(os_select)
        elif self.step == 7:
            # Final Step: Confirmation
            confirm = discord.ui.Button(label="Confirm Creation", style=discord.ButtonStyle.success)
            confirm.callback = self.confirm_callback
            cancel = discord.ui.Button(label="Cancel", style=discord.ButtonStyle.danger)
            cancel.callback = self.cancel_callback
            self.add_item(confirm)
            self.add_item(cancel)

    async def next_step(self, interaction: discord.Interaction):
        self.step += 1
        self._setup_step()
        await self.update_message(interaction)

    async def update_message(self, interaction: discord.Interaction):
        embed = discord.Embed(title=f"DVM Creation - Step {self.step} of 6", color=discord.Color.blue())
        
        summary = ""
        if self.data['user']: summary += f"**User:** {self.data['user'].mention}\n"
        if self.data['hostname']: summary += f"**Hostname:** `{self.data['hostname']}`\n"
        if self.data['ram']: summary += f"**RAM:** `{self.data['ram']}MB`\n"
        if self.data['cpu']: summary += f"**CPU:** `{self.data['cpu']} Cores`\n"
        if self.data['disk']: summary += f"**Disk:** `{self.data['disk']}GB`\n"
        if self.data['os']: summary += f"**OS:** `{self.data['os']}`\n"

        if self.step <= 6:
            embed.description = f"Please complete the step below.\n\n**Progress:**\n{summary}"
        else:
            embed.title = "📝 DVM Creation Summary"
            embed.description = f"Confirm the details below to create the DVM.\n\n{summary}"
            embed.color = discord.Color.gold()

        if interaction.response.is_done():
            await interaction.edit_original_response(embed=embed, view=self)
        else:
            await interaction.response.edit_message(embed=embed, view=self)

    # Callbacks
    async def user_select_callback(self, interaction: discord.Interaction):
        select = interaction.data['component_type'] # just a placeholder check if needed
        # In discord.py 2.0+, UserSelect values are accessed via interaction.data if not using a subclass with 'values'
        # Actually, if I add it as `self.add_item(user_select)`, I can't easily access `user_select.values` unless I keep a reference.
        # But wait, interaction.data['values'] is correct for the internal message state.
        user_id = int(interaction.data['values'][0])
        self.data['user'] = interaction.guild.get_member(user_id) or await interaction.guild.fetch_member(user_id)
        await self.next_step(interaction)

    async def hostname_btn_callback(self, interaction: discord.Interaction):
        await interaction.response.send_modal(HostnameModal(self))

    async def ram_select_callback(self, interaction: discord.Interaction):
        self.data['ram'] = int(interaction.data['values'][0])
        await self.next_step(interaction)

    async def cpu_select_callback(self, interaction: discord.Interaction):
        self.data['cpu'] = float(interaction.data['values'][0])
        await self.next_step(interaction)

    async def disk_btn_callback(self, interaction: discord.Interaction):
        await interaction.response.send_modal(DiskModal(self))

    async def os_select_callback(self, interaction: discord.Interaction):
        os_key = interaction.data['values'][0]
        self.data['os'] = os_key
        self.data['image'] = self.templates[os_key]
        await self.next_step(interaction)

    async def confirm_callback(self, interaction: discord.Interaction):
        await interaction.response.edit_message(
            embed=discord.Embed(
                title="🚀 Creating DVM...",
                description="The bot is now pulling the OS image and configuring your container. This may take a few moments depending on the image size.",
                color=discord.Color.blue()
            ),
            view=None
        )
        
        user = self.data['user']
        hostname = self.data['hostname']
        container_name = f"dvm-{user.id}-{hostname}"

        # 1. Create Docker container
        container = await docker_mgr.create_container(
            name=container_name,
            hostname=hostname,
            image=self.data['image'],
            ram_mb=self.data['ram'],
            cpu_count=self.data['cpu']
        )

        if not container:
            return await interaction.followup.send(embed=DVMEmbeds.error("Failed to create Docker container."), ephemeral=True)

        # 2. Save to DB
        await db.get_or_create_user(user.id, user.name)
        dvm = await db.create_dvm(
            user.id, 
            container_name, 
            hostname, 
            self.data['ram'], 
            self.data['cpu'], 
            self.data['disk'],
            self.data['image'],
            ssh_port=None, # tmate doesn't use static ports
            root_password="rootpass"
        )

        # 3. Notify owner via DM
        try:
            dm_embed = discord.Embed(
                title="🆕 New DVM Assigned!",
                description=(
                    f"Hello **{user.name}**! A new Docker Virtual Machine has been assigned to you.\n\n"
                    f"**Details:**\n"
                    f"🏠 Hostname: `{hostname}`\n"
                    f"🧠 RAM: `{self.data['ram']}MB`\n"
                    f"⚡ CPU: `{self.data['cpu']} Cores`\n"
                    f"💿 Disk: `{self.data['disk']}GB`\n\n"
                    f"**How to manage:**\n"
                    f"Use the `?manage` command in the server to access your control panel."
                ),
                color=discord.Color.green()
            )
            await user.send(embed=dm_embed)
            dm_status = "and notified user via DM"
        except discord.Forbidden:
            dm_status = "but could not DM user (DMs closed)"

        # 4. Success message in channel
        await interaction.followup.send(
            embed=DVMEmbeds.success(f"DVM `{hostname}` successfully created for **{user.name}** {dm_status}!\nID: `{dvm.id}`")
        )
        self.stop()

    async def cancel_callback(self, interaction: discord.Interaction):
        await interaction.response.edit_message(content="❌ DVM Creation cancelled.", embed=None, view=None)
        self.stop()
