import asyncio
import logging
import discord
import os
from database.db_handler import db
from modules.docker_manager import docker_mgr
from config import settings

logger = logging.getLogger("dvm_manager.guard")

class ResourceGuard:
    def __init__(self, bot):
        self.bot = bot
        self.running = False

    async def start(self):
        self.running = True
        logger.info("[Guard] Resource Guard system initialized.")
        while self.running:
            try:
                await self.check_dvms()
            except Exception as e:
                logger.error(f"[Guard] Loop error: {e}")
            await asyncio.sleep(5) # Performance requirement: check every 5 seconds

    async def check_dvms(self):
        # Cache DVM list to reduce DB reads (Scalability optimization)
        dvms = await db.get_all_dvms()
        
        # Monitor RAM and Disk
        tasks = [self.monitor_logic(dvm) for dvm in dvms if not dvm.suspended]
        await asyncio.gather(*tasks)

    async def monitor_logic(self, dvm):
        # 1. Fetch real-time stats
        stats = await docker_mgr.get_container_stats(dvm.container_name)
        if not stats or stats.get('status') != 'running':
            return

        # RAM monitoring (Threshold: 95%)
        mem_usage = stats.get('mem_usage_mb', 0)
        mem_limit = dvm.ram_limit_mb
        mem_percent = (mem_usage / mem_limit) * 100 if mem_limit > 0 else 0

        # Disk monitoring (Threshold: 95%)
        disk_usage = await docker_mgr.get_disk_usage(dvm.container_name)
        disk_limit_bytes = dvm.disk_limit_gb * 1024 * 1024 * 1024
        disk_percent = (disk_usage / disk_limit_bytes) * 100 if disk_limit_bytes > 0 else 0

        if mem_percent >= 95 or disk_percent >= 95:
            reason = "RAM Usage" if mem_percent >= 95 else "Disk Usage"
            logger.warning(f"[Guard] DVM {dvm.hostname} reached {reason} limit ({mem_percent:.1f}% RAM, {disk_percent:.1f}% Disk). Triggering rescue flow.")
            await self.rescue_flow(dvm, reason)

    async def rescue_flow(self, dvm, reason: str):
        """Simplified Flow: Notify -> Delete."""
        # 1. Notify User via DM
        try:
            user = await self.bot.fetch_user(dvm.owner_discord_id)
            embed = discord.Embed(
                title="⚠️ DVM Shutdown Notice",
                description=(
                    f"Your VPS **{dvm.hostname}** exceeded its allowed resources (**{reason}**).\n\n"
                    "Your VPS has been removed to protect system stability.\n\n"
                    "Please contact the admin to discuss creating a new VPS."
                ),
                color=discord.Color.red()
            )
            await user.send(embed=embed)
            logger.info(f"[Guard] User {user.id} notified of shutdown.")
        except Exception as e:
            logger.error(f"[Guard] Could not notify user {dvm.owner_discord_id}: {e}")

        # 2. Delete Container and record
        logger.info(f"[Guard] Removing DVM {dvm.id} from system.")
        await docker_mgr.remove_container(dvm.container_name)
        await db.delete_dvm(dvm.id)

async def start_guard(bot):
    guard = ResourceGuard(bot)
    await guard.start()
