import discord
import os
from database.db_handler import db
from modules.docker_manager import docker_mgr
from config import settings

class SuspensionView(discord.ui.View):
    def __init__(self, admin_interaction: discord.Interaction, target_user: discord.Member, dvms: list):
        super().__init__(timeout=60)
        self.admin = admin_interaction.user
        self.target_user = target_user
        self.dvms = dvms
        self.selected_dvm_id = None
        
        # Add Select Menu for DVMs
        options = [
            discord.SelectOption(
                label=dvm.hostname,
                description=f"ID: {dvm.id} | {dvm.container_name}",
                value=str(dvm.id)
            ) for dvm in dvms
        ]
        self.select = discord.ui.Select(placeholder="Select DVM to Backup & Delete...", options=options)
        self.select.callback = self.select_callback
        self.add_item(self.select)
        
        # Add Confirm Button
        self.confirm_btn = discord.ui.Button(label="Confirm & Backup", style=discord.ButtonStyle.danger, disabled=True)
        self.confirm_btn.callback = self.confirm_callback
        self.add_item(self.confirm_btn)

    async def select_callback(self, interaction: discord.Interaction):
        self.selected_dvm_id = int(interaction.data['values'][0])
        self.confirm_btn.disabled = False
        await interaction.response.edit_message(view=self)

    async def confirm_callback(self, interaction: discord.Interaction):
        dvm = next((d for d in self.dvms if d.id == self.selected_dvm_id), None)
        if not dvm:
            return await interaction.response.send_message("Selection Error.", ephemeral=True)

        await interaction.response.edit_message(content=f"⏳ Removing `{dvm.hostname}`...", view=None, embed=None)
        
        # 1. Notify User via DM
        try:
            embed = discord.Embed(
                title="🗑️ DVM Deletion Notice",
                description=(
                    f"Hello **{self.target_user.name}**, your DVM **{dvm.hostname}** has been removed by an administrator.\n"
                    "Please contact the owner if you have any questions."
                ),
                color=discord.Color.red()
            )
            await self.target_user.send(embed=embed)
            dm_status = "✅ User notified via DM."
        except Exception as e:
            dm_status = f"❌ Could not DM user notice. Error: {e}"

        # 2. Delete Container and record
        await docker_mgr.remove_container(dvm.container_name)
        await db.delete_dvm(dvm.id)
        
        await interaction.followup.send(f"✅ DVM `{dvm.hostname}` (ID: {dvm.id}) has been permanently deleted. {dm_status}")
