import discord
from typing import List, Dict, Any
import asyncio
from modules.docker_manager import docker_mgr
from modules.ssh_manager import ssh_mgr
from database.db_handler import db
from ui.embeds import DVMEmbeds
import logging

logger = logging.getLogger("dvm_manager.ui")

class DVMControlButton(discord.ui.Button):
    def __init__(self, label: str, style: discord.ButtonStyle, action: str, dvm_id: int):
        super().__init__(label=label, style=style)
        self.action = action
        self.dvm_id = dvm_id

    async def callback(self, interaction: discord.Interaction):
        # This will be handled in the main View class to keep context
        await self.view.handle_action(interaction, self.action, self.dvm_id)

class DVMSelect(discord.ui.Select):
    def __init__(self, dvms: List[Any]):
        options = [
            discord.SelectOption(
                label=dvm.hostname,
                description=f"Container: {dvm.container_name}",
                value=str(dvm.id),
                emoji="🖥️"
            ) for dvm in dvms
        ]
        super().__init__(placeholder="Select your DVM to manage...", options=options)

    async def callback(self, interaction: discord.Interaction):
        await self.view.select_dvm(interaction, int(self.values[0]))

class DVMControlView(discord.ui.View):
    def __init__(self, user_id: int, dvms: List[Any]):
        super().__init__(timeout=600) # 10 minute timeout
        self.user_id = user_id
        self.dvms = {dvm.id: dvm for dvm in dvms}
        self.selected_dvm_id = None
        self.update_task = None
        
        # Add Select Menu
        self.add_item(DVMSelect(dvms))

    async def select_dvm(self, interaction: discord.Interaction, dvm_id: int):
        self.selected_dvm_id = dvm_id
        await self.refresh_interface(interaction)
        
        # Start background update task if not running
        if self.update_task is None:
            self.update_task = asyncio.create_task(self.background_update(interaction))

    def add_control_buttons(self):
        # Clear existing buttons (keep select menu at index 0)
        self.clear_items()
        # Re-add select menu
        dvms_list = list(self.dvms.values())
        self.add_item(DVMSelect(dvms_list))
        
        # Add control buttons
        actions = [
            ("Start", discord.ButtonStyle.green, "start"),
            ("Restart", discord.ButtonStyle.blurple, "restart"),
            ("Stop", discord.ButtonStyle.red, "stop"),
            ("SSH Access", discord.ButtonStyle.gray, "ssh"),
            ("Refresh", discord.ButtonStyle.gray, "refresh")
        ]
        
        for label, style, action in actions:
            self.add_item(DVMControlButton(label, style, action, self.selected_dvm_id))

    async def handle_action(self, interaction: discord.Interaction, action: str, dvm_id: int):
        dvm = self.dvms.get(dvm_id)
        if not dvm:
            return await interaction.response.send_message("DVM not found.", ephemeral=True)

        if dvm.suspended and action != "refresh":
            return await interaction.response.send_message("❌ This DVM is suspended. Contact administration.", ephemeral=True)

        await interaction.response.defer()

        if action == "start":
            await docker_mgr.start_container(dvm.container_name)
        elif action == "stop":
            await docker_mgr.stop_container(dvm.container_name)
        elif action == "restart":
            await docker_mgr.restart_container(dvm.container_name)
        elif action == "ssh":
            # Inform user
            status_msg = await interaction.followup.send("⏳ **[SSH] Generating tmate session... please wait**", ephemeral=True)
            
            # Setup tmate following user request
            ssh_link = await ssh_mgr.setup_tmate(dvm.container_name, image_type=dvm.image)
            
            if ssh_link:
                try:
                    embed = discord.Embed(
                        title="DVM SSH Access (tmate)",
                        description=(
                            "Your temporary tmate session is ready.\n\n"
                            "**Link:**\n"
                            f"```bash\n{ssh_link}\n```\n\n"
                            "*Note: Session expires when tmate is stopped.*"
                        ),
                        color=discord.Color.gold()
                    )
                    await interaction.user.send(embed=embed)
                    await status_msg.edit(content="✅ **tmate link sent to your DMs!**")
                    logger.info(f"[SSH] Successfully sent DM to {interaction.user.name}")
                except discord.Forbidden:
                    await status_msg.edit(content="❌ **Could not DM you. Please enable DMs.**")
            else:
                await status_msg.edit(content="❌ **Failed to initialize tmate session. Check bot logs.**")
            return

        await self.refresh_interface(interaction, is_followup=True)

    async def refresh_interface(self, interaction: discord.Interaction, is_followup=False):
        if self.selected_dvm_id is None:
            return

        dvm = self.dvms.get(self.selected_dvm_id)
        # Fetch fresh data from DB to check status/suspension
        # In a real app we'd query DB here
        
        stats = await docker_mgr.get_container_stats(dvm.container_name)
        
        # Update buttons
        self.add_control_buttons()
        
        embed = DVMEmbeds.control_panel({
            "id": dvm.id,
            "container_name": dvm.container_name,
            "hostname": dvm.hostname,
            "status": stats.get('status', 'offline')
        }, stats)

        if is_followup:
            await interaction.followup.edit_message(message_id=interaction.message.id, embed=embed, view=self)
        else:
            await interaction.response.edit_message(embed=embed, view=self)

    async def background_update(self, interaction: discord.Interaction):
        """Task to update the stats every 5 seconds."""
        try:
            while not self.is_finished():
                await asyncio.sleep(5)
                if self.selected_dvm_id and interaction.message:
                    dvm = self.dvms.get(self.selected_dvm_id)
                    stats = await docker_mgr.get_container_stats(dvm.container_name)
                    
                    embed = DVMEmbeds.control_panel({
                        "id": dvm.id,
                        "container_name": dvm.container_name,
                        "hostname": dvm.hostname,
                        "status": stats.get('status', 'offline')
                    }, stats)
                    
                    try:
                        await interaction.message.edit(embed=embed, view=self)
                    except Exception:
                        break # Stop if message deleted or other error
        except asyncio.CancelledError:
            pass
