import asyncio
import logging
import socket
from modules.docker_manager import docker_mgr
from config import settings

logger = logging.getLogger("dvm_manager.ssh")

class SSHManager:
    @staticmethod
    def get_free_port():
        """Finds an available host port for random usage."""
        s = socket.socket()
        s.bind(('', 0))
        port = s.getsockname()[1]
        s.close()
        return port

    @staticmethod
    async def setup_tmate(container_name: str, image_type: str = "ubuntu"):
        """
        Sets up a tmate session and retrieves the SSH connection string.
        Reverted to tmate as per user request.
        """
        logger.info(f"[SSH] Starting tmate setup for {container_name}")
        
        is_alpine = "alpine" in image_type.lower()
        shell = "sh" if is_alpine else "bash"
        socket_path = "/tmp/tmate.sock"
        
        # 1. Install tmate
        if is_alpine:
            install_cmd = "apk add --no-cache tmate openssh-client"
        else:
            install_cmd = "export DEBIAN_FRONTEND=noninteractive && apt-get update && apt-get install -y tmate openssh-client"
        
        await docker_mgr.execute_command(container_name, f"{shell} -c '{install_cmd}'")

        # 2. Ensure SSH keys
        await docker_mgr.execute_command(container_name, f"{shell} -c 'mkdir -p ~/.ssh && [ -f ~/.ssh/id_rsa ] || ssh-keygen -t rsa -f ~/.ssh/id_rsa -N \"\"'")

        # 3. Start Session
        logger.info("[SSH] Starting tmate session...")
        await docker_mgr.execute_command(container_name, f"{shell} -c 'tmate -S {socket_path} kill-session 2>/dev/null || true'")
        await docker_mgr.execute_command(container_name, f"{shell} -c 'tmate -S {socket_path} new-session -d'")
        
        # 4. Wait for ready
        logger.info("[SSH] Waiting for tmate server...")
        try:
            # wait tmate-ready
            await asyncio.wait_for(
                docker_mgr.execute_command(container_name, f"{shell} -c 'tmate -S {socket_path} wait tmate-ready'"), 
                timeout=25
            )
            logger.info("[SSH] tmate ready.")
        except asyncio.TimeoutError:
            logger.error("[SSH] Timeout waiting for tmate-ready.")
            return None

        # 5. Fetch link
        display_cmd = f"tmate -S {socket_path} display -p '#{{tmate_ssh}}'"
        for i in range(10):
            code, output = await docker_mgr.execute_command(container_name, f"{shell} -c \"{display_cmd}\"")
            clean = output.strip() if output else ""
            if "ssh " in clean:
                logger.info(f"[SSH] Link retrieved: {clean}")
                return clean
            await asyncio.sleep(2)

        logger.error("[SSH] Failed to retrieve tmate link.")
        return None

    # Keeping this for legacy compatibility if called
    async def get_server_ip(self):
        return "Not Applicable for tmate"

ssh_mgr = SSHManager()
