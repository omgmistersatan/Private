# DVM Manager - Docker Virtual Machine Management Bot

DVM Manager is a powerful Discord bot that allows you to manage lightweight VPS-like containers (Docker Virtual Machines) directly from Discord.

## Features
- **Mini VPS Experience**: Each container has its own RAM, CPU, and hostname.
- **Interactive Control Panel**: Real-time monitoring and control for users via `?manage`.
- **Automated SSH**: One-click SSH access via `tmate` sent to DMs.
- **Administrator Suite**: Over 50 management commands for creation, suspension, and resource control.
- **Production Ready**: Built with `discord.py`, `Docker SDK`, and `SQLAlchemy`.

## Deployment
1. **Clone the repository.**
2. **Configure environment**:
   - Rename `.env` template and fill in your `DISCORD_TOKEN` and `OWNER_ID`.
3. **Run with Docker Compose**:
   ```bash
   docker compose up -d
   ```

## Admin Commands
| Command | Description |
| --- | --- |
| `/create_dvm` | Create a new instance for a user |
| `/delete_dvm` | Delete an instance |
| `/suspend_dvm` | Suspend an instance |
| `/set_ram` | Update RAM limits |
| `/node_info` | View host hardware usage |
| `/list_dvms` | List all containers |

## User Command
- `?manage`: Opens the interactive DVM control panel.

## Requirements
- Docker & Docker Compose
- Python 3.11+ (if running locally)
