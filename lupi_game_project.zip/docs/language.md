# Lupi v1.1.0

## Recursos principais
- `import` e `from`
- `pyimport` e `frompy`
- `input`, `color`, `printc`
- `break` e `continue`
- módulo `game`

## Exemplo de import Python
```lupi
pyimport xml.etree.ElementTree as ET
frompy math import sqrt
```

## Exemplo de jogo
```lupi
import game

game.window(800, 600, "Jogo")

fn draw():
    game.clear("black")
    game.text("Olá", 20, 20, "yellow")

game.run()
```
