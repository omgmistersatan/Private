# CLI

```bash
lupi version
lupi arquivo.lp
lupi run arquivo.lp
lupi install requests
```

Para jogos:
```bash
lupi install pygame-ce
```
