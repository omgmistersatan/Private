# Lupi v1.1.0

Linguagem de programação experimental inspirada em Lua e Python.

## Recursos
- variáveis, listas e mapas
- `if`, `while`, `for`, `break`, `continue`
- `fn` e `return`
- `import` de módulos `.lp`
- `pyimport` / `frompy` para módulos Python
- `input()`, `print()`, `color()` e `printc()`
- módulo `game` embutido (requer `pygame-ce` para rodar jogos)

## CLI
```bash
lupi version
lupi examples/main.lp
lupi install requests
```

## Suporte a jogo
Instale dependências opcionais:
```bash
python -m pip install "lupi-lang[game]"
```
