from __future__ import annotations

import argparse
import importlib
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Optional

from .game_runtime import game_namespace, GameUnavailable


class LupiError(Exception):
    pass


class ReturnSignal(Exception):
    def __init__(self, value: Any):
        self.value = value


class BreakSignal(Exception):
    pass


class ContinueSignal(Exception):
    pass


@dataclass
class Token:
    type: str
    value: Any
    line: int
    col: int


KEYWORDS = {
    'if', 'elif', 'else', 'while', 'for', 'in', 'fn', 'return', 'let', 'break', 'continue',
    'true', 'false', 'nil', 'and', 'or', 'not', 'import', 'from', 'as', 'pyimport', 'frompy'
}


class Lexer:
    def __init__(self, source: str):
        self.source = source.replace('\r\n', '\n').replace('\r', '\n')

    def tokenize(self):
        tokens = []
        lines = self.source.split('\n')
        indent_stack = [0]
        for line_no, raw in enumerate(lines, start=1):
            if raw.strip() == '':
                continue
            indent = len(raw) - len(raw.lstrip(' '))
            if indent % 4 != 0:
                raise LupiError(f'Indentacao deve usar multiplos de 4 espacos (linha {line_no})')
            if indent > indent_stack[-1]:
                indent_stack.append(indent)
                tokens.append(Token('INDENT', None, line_no, 1))
            while indent < indent_stack[-1]:
                indent_stack.pop()
                tokens.append(Token('DEDENT', None, line_no, 1))
            if indent != indent_stack[-1]:
                raise LupiError(f'Indentacao inconsistente (linha {line_no})')
            i = indent
            line = raw
            while i < len(line):
                ch = line[i]
                col = i + 1
                if ch in ' \t':
                    i += 1
                    continue
                if ch == '#':
                    break
                for typ, text in [('RANGE_INCL', '..='), ('RANGE', '..'), ('ARROW_FN', '=>'), ('EQ', '=='), ('NE', '!='), ('LE', '<='), ('GE', '>='), ('FLOORDIV', '//'), ('PLUSEQ', '+='), ('MINUSEQ', '-=')]:
                    if line.startswith(text, i):
                        tokens.append(Token(typ, text, line_no, col))
                        i += len(text)
                        break
                else:
                    single = {'(': 'LPAREN', ')': 'RPAREN', '[': 'LBRACKET', ']': 'RBRACKET', '{': 'LBRACE', '}': 'RBRACE', ',': 'COMMA', ':': 'COLON', '+': 'PLUS', '-': 'MINUS', '*': 'STAR', '/': 'SLASH', '%': 'PERCENT', '=': 'ASSIGN', '<': 'LT', '>': 'GT', '.': 'DOT'}
                    if ch in single:
                        tokens.append(Token(single[ch], ch, line_no, col))
                        i += 1
                        continue
                    if ch in ('"', "'"):
                        quote = ch
                        i += 1
                        value = ''
                        while i < len(line):
                            if line[i] == '\\':
                                esc = line[i+1]
                                value += {'n':'\n','t':'\t','"':'"',"'":"'",'\\':'\\'}.get(esc, esc)
                                i += 2
                                continue
                            if line[i] == quote:
                                break
                            value += line[i]
                            i += 1
                        else:
                            raise LupiError(f'String nao fechada na linha {line_no}')
                        tokens.append(Token('STRING', value, line_no, col))
                        i += 1
                        continue
                    if ch.isdigit():
                        start = i
                        has_dot = False
                        while i < len(line) and (line[i].isdigit() or (line[i] == '.' and not has_dot and not line.startswith('..', i))):
                            if line[i] == '.':
                                has_dot = True
                            i += 1
                        text = line[start:i]
                        tokens.append(Token('NUMBER', float(text) if '.' in text else int(text), line_no, col))
                        continue
                    if ch.isalpha() or ch == '_':
                        start = i
                        while i < len(line) and (line[i].isalnum() or line[i] == '_'):
                            i += 1
                        text = line[start:i]
                        tokens.append(Token(text.upper() if text in KEYWORDS else 'IDENT', text, line_no, col))
                        continue
                    raise LupiError(f'Caractere inesperado {ch!r} na linha {line_no}, coluna {col}')
            tokens.append(Token('NEWLINE', None, line_no, len(line) + 1))
        while len(indent_stack) > 1:
            indent_stack.pop()
            tokens.append(Token('DEDENT', None, len(lines), 1))
        tokens.append(Token('EOF', None, len(lines) + 1, 1))
        return tokens


@dataclass
class Program: body: list
@dataclass
class Block: statements: list
@dataclass
class Number: value: Any
@dataclass
class String: value: str
@dataclass
class Boolean: value: bool
@dataclass
class Nil: pass
@dataclass
class Var: name: str
@dataclass
class ListLiteral: items: list
@dataclass
class MapLiteral: items: list
@dataclass
class Assign: name: str; expr: Any; constant: bool=False
@dataclass
class SetAttrStmt: obj: Any; name: str; expr: Any
@dataclass
class AugAssign: name: str; op: str; expr: Any
@dataclass
class Binary: left: Any; op: str; right: Any
@dataclass
class Unary: op: str; expr: Any
@dataclass
class Call: callee: Any; args: list
@dataclass
class GetAttr: obj: Any; name: str
@dataclass
class RangeExpr: start: Any; end: Any; inclusive: bool
@dataclass
class IfStmt: branches: list; else_block: Optional[Block]
@dataclass
class WhileStmt: condition: Any; block: Block
@dataclass
class ForStmt: var_name: str; iterable: Any; block: Block
@dataclass
class FnDecl: name: str; params: list; block: Block
@dataclass
class ReturnStmt: expr: Any | None
@dataclass
class ExprStmt: expr: Any
@dataclass
class ImportStmt: module: str; alias: str | None = None
@dataclass
class FromImportStmt: module: str; names: list
@dataclass
class PyImportStmt: module: str; alias: str | None = None
@dataclass
class FromPyImportStmt: module: str; names: list
@dataclass
class BreakStmt: pass
@dataclass
class ContinueStmt: pass


class Parser:
    def __init__(self, tokens):
        self.tokens = tokens
        self.pos = 0

    def current(self): return self.tokens[self.pos]
    def peek(self, offset=1): return self.tokens[min(self.pos + offset, len(self.tokens)-1)]
    def match(self, *types):
        if self.current().type in types:
            tok = self.current(); self.pos += 1; return tok
        return None
    def expect(self, type_):
        tok = self.current()
        if tok.type != type_:
            raise LupiError(f'Esperado {type_}, encontrado {tok.type} na linha {tok.line}')
        self.pos += 1; return tok
    def skip_newlines(self):
        while self.match('NEWLINE'): pass
    def parse(self):
        body=[]; self.skip_newlines()
        while self.current().type != 'EOF':
            body.append(self.parse_statement()); self.skip_newlines()
        return Program(body)
    def parse_statement(self):
        tok = self.current()
        if tok.type == 'LET': return self.parse_assignment(True)
        if tok.type == 'IF': return self.parse_if()
        if tok.type == 'WHILE': return self.parse_while()
        if tok.type == 'FOR': return self.parse_for()
        if tok.type == 'FN': return self.parse_fn_decl()
        if tok.type == 'RETURN': return self.parse_return()
        if tok.type == 'IMPORT': return self.parse_import()
        if tok.type == 'FROM': return self.parse_from_import()
        if tok.type == 'PYIMPORT': return self.parse_pyimport()
        if tok.type == 'FROMPY': return self.parse_frompy_import()
        if tok.type == 'BREAK': self.expect('BREAK'); return BreakStmt()
        if tok.type == 'CONTINUE': self.expect('CONTINUE'); return ContinueStmt()
        if tok.type == 'IDENT' and self.peek().type in ('ASSIGN','PLUSEQ','MINUSEQ'):
            if self.peek().type == 'ASSIGN': return self.parse_assignment(False)
            name = self.expect('IDENT').value; op=self.current().type; self.pos+=1; return AugAssign(name, op, self.parse_expression())
        if tok.type == 'IDENT' and self.peek().type == 'DOT':
            target = self.parse_attr_chain()
            if isinstance(target, GetAttr) and self.current().type == 'ASSIGN':
                self.expect('ASSIGN')
                return SetAttrStmt(target.obj, target.name, self.parse_expression())
            self.pos -= 0
        return ExprStmt(self.parse_expression())
    def parse_attr_chain(self):
        expr = Var(self.expect('IDENT').value)
        while self.match('DOT'):
            expr = GetAttr(expr, self.expect('IDENT').value)
        return expr
    def parse_import(self):
        self.expect('IMPORT'); mod = self.parse_dotted_name(); alias = self.expect('IDENT').value if self.match('AS') else None; return ImportStmt(mod, alias)
    def parse_from_import(self):
        self.expect('FROM'); mod = self.parse_dotted_name(); self.expect('IMPORT'); names=[self.expect('IDENT').value]
        while self.match('COMMA'): names.append(self.expect('IDENT').value)
        return FromImportStmt(mod, names)
    def parse_pyimport(self):
        self.expect('PYIMPORT'); mod = self.parse_dotted_name(); alias = self.expect('IDENT').value if self.match('AS') else None; return PyImportStmt(mod, alias)
    def parse_frompy_import(self):
        self.expect('FROMPY'); mod = self.parse_dotted_name(); self.expect('IMPORT'); names=[self.expect('IDENT').value]
        while self.match('COMMA'): names.append(self.expect('IDENT').value)
        return FromPyImportStmt(mod, names)
    def parse_dotted_name(self):
        parts=[self.expect('IDENT').value]
        while self.match('DOT'): parts.append(self.expect('IDENT').value)
        return '.'.join(parts)
    def parse_assignment(self, constant=False):
        if constant: self.expect('LET')
        name = self.expect('IDENT').value; self.expect('ASSIGN'); return Assign(name, self.parse_expression(), constant)
    def parse_if(self):
        self.expect('IF'); branches=[]; cond=self.parse_expression(); self.expect('COLON'); branches.append((cond, self.parse_block()))
        while self.current().type == 'ELIF':
            self.expect('ELIF'); cond=self.parse_expression(); self.expect('COLON'); branches.append((cond, self.parse_block()))
        else_block = None
        if self.current().type == 'ELSE': self.expect('ELSE'); self.expect('COLON'); else_block = self.parse_block()
        return IfStmt(branches, else_block)
    def parse_while(self):
        self.expect('WHILE'); cond=self.parse_expression(); self.expect('COLON'); return WhileStmt(cond, self.parse_block())
    def parse_for(self):
        self.expect('FOR'); name=self.expect('IDENT').value; self.expect('IN'); iterable=self.parse_expression(); self.expect('COLON'); return ForStmt(name, iterable, self.parse_block())
    def parse_fn_decl(self):
        self.expect('FN'); name=self.expect('IDENT').value; self.expect('LPAREN'); params=[]
        if self.current().type != 'RPAREN':
            params.append(self.expect('IDENT').value)
            while self.match('COMMA'): params.append(self.expect('IDENT').value)
        self.expect('RPAREN')
        if self.match('ARROW_FN'): return FnDecl(name, params, Block([ReturnStmt(self.parse_expression())]))
        self.expect('COLON'); return FnDecl(name, params, self.parse_block())
    def parse_return(self):
        self.expect('RETURN')
        if self.current().type in ('NEWLINE','DEDENT','EOF'): return ReturnStmt(None)
        return ReturnStmt(self.parse_expression())
    def parse_block(self):
        self.expect('NEWLINE'); self.expect('INDENT'); body=[]; self.skip_newlines()
        while self.current().type not in ('DEDENT','EOF'):
            body.append(self.parse_statement()); self.skip_newlines()
        self.expect('DEDENT'); return Block(body)
    def parse_expression(self): return self.parse_range()
    def parse_range(self):
        expr = self.parse_or()
        if self.current().type in ('RANGE','RANGE_INCL'):
            inclusive = self.current().type == 'RANGE_INCL'; self.pos += 1; return RangeExpr(expr, self.parse_or(), inclusive)
        return expr
    def parse_or(self):
        expr=self.parse_and()
        while self.match('OR'): expr=Binary(expr,'or',self.parse_and())
        return expr
    def parse_and(self):
        expr=self.parse_equality()
        while self.match('AND'): expr=Binary(expr,'and',self.parse_equality())
        return expr
    def parse_equality(self):
        expr=self.parse_comparison()
        while self.current().type in ('EQ','NE'):
            op=self.current().value; self.pos+=1; expr=Binary(expr,op,self.parse_comparison())
        return expr
    def parse_comparison(self):
        expr=self.parse_term()
        while self.current().type in ('LT','LE','GT','GE'):
            op=self.current().value; self.pos+=1; expr=Binary(expr,op,self.parse_term())
        return expr
    def parse_term(self):
        expr=self.parse_factor()
        while self.current().type in ('PLUS','MINUS'):
            op=self.current().value; self.pos+=1; expr=Binary(expr,op,self.parse_factor())
        return expr
    def parse_factor(self):
        expr=self.parse_unary()
        while self.current().type in ('STAR','SLASH','FLOORDIV','PERCENT'):
            op=self.current().value; self.pos+=1; expr=Binary(expr,op,self.parse_unary())
        return expr
    def parse_unary(self):
        if self.current().type in ('MINUS','NOT'):
            op=self.current().value; self.pos+=1; return Unary(op, self.parse_unary())
        return self.parse_call()
    def parse_call(self):
        expr=self.parse_primary()
        while True:
            if self.match('LPAREN'):
                args=[]
                if self.current().type != 'RPAREN':
                    args.append(self.parse_expression())
                    while self.match('COMMA'): args.append(self.parse_expression())
                self.expect('RPAREN'); expr=Call(expr,args)
            elif self.match('DOT'):
                expr=GetAttr(expr,self.expect('IDENT').value)
            else:
                break
        return expr
    def parse_primary(self):
        tok=self.current()
        if self.match('NUMBER'): return Number(tok.value)
        if self.match('STRING'): return String(tok.value)
        if self.match('TRUE'): return Boolean(True)
        if self.match('FALSE'): return Boolean(False)
        if self.match('NIL'): return Nil()
        if self.match('IDENT'): return Var(tok.value)
        if self.match('LBRACKET'):
            items=[]
            if self.current().type != 'RBRACKET':
                items.append(self.parse_expression())
                while self.match('COMMA'): items.append(self.parse_expression())
            self.expect('RBRACKET'); return ListLiteral(items)
        if self.match('LBRACE'):
            items=[]
            if self.current().type != 'RBRACE':
                items.append(self.parse_map_item())
                while self.match('COMMA'): items.append(self.parse_map_item())
            self.expect('RBRACE'); return MapLiteral(items)
        if self.match('LPAREN'):
            expr=self.parse_expression(); self.expect('RPAREN'); return expr
        raise LupiError(f'Expressao invalida na linha {tok.line}, coluna {tok.col}')
    def parse_map_item(self):
        key = String(self.expect('IDENT').value) if self.current().type == 'IDENT' and self.peek().type == 'COLON' else self.parse_expression()
        self.expect('COLON'); return key, self.parse_expression()


class Env:
    def __init__(self, parent=None): self.parent=parent; self.values={}; self.constants=set()
    def define(self, name, value, constant=False): self.values[name]=value; self.constants.add(name) if constant else None
    def get(self, name):
        if name in self.values: return self.values[name]
        if self.parent: return self.parent.get(name)
        raise LupiError(f'Variavel indefinida: {name}')
    def set(self, name, value):
        if name in self.values:
            if name in self.constants: raise LupiError(f'Nao pode alterar constante: {name}')
            self.values[name]=value; return
        if self.parent: return self.parent.set(name, value)
        self.values[name]=value


class AttrDict(dict):
    def __getattr__(self, item):
        try: return self[item]
        except KeyError as e: raise AttributeError(item) from e
    def __setattr__(self, key, value): self[key]=value


class LupiModule:
    def __init__(self, name, values): self.__name__=name; self.__dict__.update(values)
    def __repr__(self): return f'<module {self.__name__}>'


class UserFunction:
    def __init__(self, name, params, block, closure): self.name=name; self.params=params; self.block=block; self.closure=closure
    def __call__(self, interp, args):
        if len(args) != len(self.params): raise LupiError(f'Funcao {self.name} esperava {len(self.params)} args, recebeu {len(args)}')
        local=Env(self.closure)
        for p,a in zip(self.params,args): local.define(p,a)
        try: interp.exec_block(self.block, local)
        except ReturnSignal as rs: return rs.value
        return None


ANSI = {
    'black':'30','red':'31','green':'32','yellow':'33','blue':'34','magenta':'35','cyan':'36','white':'37',
    'bright_red':'91','bright_green':'92','bright_yellow':'93','bright_blue':'94','bright_magenta':'95','bright_cyan':'96'
}


class Interpreter:
    def __init__(self, module_search_dir=None):
        self.global_env=Env(); self.env=self.global_env; self.module_cache={}; self.py_module_cache={}; self.module_search_dir=Path(module_search_dir or '.')
        self._install_builtins()
        self.global_env.define('game', game_namespace(self), constant=True)
    def _install_builtins(self):
        for name, fn in [('print', self.builtin_print), ('input', self.builtin_input), ('len', len), ('str', str), ('int', int), ('float', float), ('range', self.builtin_range), ('color', self.builtin_color), ('printc', self.builtin_printc)]:
            self.global_env.define(name, fn, constant=True)
    def builtin_print(self, *args): print(*args); return None
    def builtin_input(self, prompt=''): return input(str(prompt))
    def builtin_range(self, start, end=None, step=1): return list(range(start)) if end is None else list(range(start, end, step))
    def builtin_color(self, text, color): return f"\033[{ANSI.get(str(color).lower(), '37')}m{str(text)}\033[0m"
    def builtin_printc(self, text, color): print(self.builtin_color(text, color)); return None
    def run(self, program): self.exec_block(Block(program.body), self.global_env)
    def exec_block(self, block, env):
        prev=self.env; self.env=env
        try:
            for stmt in block.statements: self.exec_stmt(stmt)
        finally: self.env=prev
    def exec_stmt(self, stmt):
        if isinstance(stmt, Assign):
            value=self.eval_expr(stmt.expr)
            if stmt.constant: self.env.define(stmt.name,value,constant=True)
            elif stmt.name in self.env.values: self.env.set(stmt.name,value)
            else: self.env.define(stmt.name,value)
            return
        if isinstance(stmt, SetAttrStmt):
            obj=self.eval_expr(stmt.obj); value=self.eval_expr(stmt.expr)
            if isinstance(obj, dict): obj[stmt.name]=value
            else: setattr(obj, stmt.name, value)
            return
        if isinstance(stmt, AugAssign):
            current=self.env.get(stmt.name); value=self.eval_expr(stmt.expr); self.env.set(stmt.name, current + value if stmt.op == 'PLUSEQ' else current - value); return
        if isinstance(stmt, ExprStmt): self.eval_expr(stmt.expr); return
        if isinstance(stmt, IfStmt):
            for cond, block in stmt.branches:
                if self.truthy(self.eval_expr(cond)): self.exec_block(block, Env(self.env)); return
            if stmt.else_block: self.exec_block(stmt.else_block, Env(self.env))
            return
        if isinstance(stmt, WhileStmt):
            while self.truthy(self.eval_expr(stmt.condition)):
                try: self.exec_block(stmt.block, Env(self.env))
                except ContinueSignal: continue
                except BreakSignal: break
            return
        if isinstance(stmt, ForStmt):
            for item in self.eval_expr(stmt.iterable):
                loop=Env(self.env); loop.define(stmt.var_name,item)
                try: self.exec_block(stmt.block, loop)
                except ContinueSignal: continue
                except BreakSignal: break
            return
        if isinstance(stmt, FnDecl): self.env.define(stmt.name, UserFunction(stmt.name, stmt.params, stmt.block, self.env)); return
        if isinstance(stmt, ReturnStmt): raise ReturnSignal(self.eval_expr(stmt.expr) if stmt.expr is not None else None)
        if isinstance(stmt, ImportStmt):
            if stmt.module == 'game': self.env.define(stmt.alias or 'game', self.global_env.get('game')); return
            mod=self.load_lupi_module(stmt.module); self.env.define(stmt.alias or stmt.module.split('.')[-1], mod); return
        if isinstance(stmt, FromImportStmt):
            mod=self.load_lupi_module(stmt.module)
            for name in stmt.names:
                if not hasattr(mod,name): raise LupiError(f'Modulo {stmt.module} nao exporta {name}')
                self.env.define(name,getattr(mod,name))
            return
        if isinstance(stmt, PyImportStmt): self.env.define(stmt.alias or stmt.module.split('.')[-1], self.load_py_module(stmt.module)); return
        if isinstance(stmt, FromPyImportStmt):
            mod=self.load_py_module(stmt.module)
            for name in stmt.names:
                if not hasattr(mod,name): raise LupiError(f'Modulo Python {stmt.module} nao exporta {name}')
                self.env.define(name,getattr(mod,name))
            return
        if isinstance(stmt, BreakStmt): raise BreakSignal()
        if isinstance(stmt, ContinueStmt): raise ContinueSignal()
        raise LupiError(f'Statement nao suportado: {stmt}')
    def eval_expr(self, expr):
        if isinstance(expr, Number): return expr.value
        if isinstance(expr, String): return expr.value
        if isinstance(expr, Boolean): return expr.value
        if isinstance(expr, Nil): return None
        if isinstance(expr, Var): return self.env.get(expr.name)
        if isinstance(expr, ListLiteral): return [self.eval_expr(x) for x in expr.items]
        if isinstance(expr, MapLiteral): return AttrDict({self.eval_expr(k): self.eval_expr(v) for k,v in expr.items})
        if isinstance(expr, Unary):
            v=self.eval_expr(expr.expr)
            if expr.op == '-': return -v
            if expr.op == 'not': return not self.truthy(v)
        if isinstance(expr, Binary):
            left=self.eval_expr(expr.left)
            if expr.op == 'and': return self.eval_expr(expr.right) if self.truthy(left) else left
            if expr.op == 'or': return left if self.truthy(left) else self.eval_expr(expr.right)
            right=self.eval_expr(expr.right)
            return {'+':left+right,'-':left-right,'*':left*right,'/':left/right,'//':left//right,'%':left%right,'==':left==right,'!=':left!=right,'<':left<right,'<=':left<=right,'>':left>right,'>=':left>=right}[expr.op]
        if isinstance(expr, Call):
            callee=self.eval_expr(expr.callee); args=[self.eval_expr(a) for a in expr.args]
            if isinstance(callee, UserFunction): return callee(self,args)
            if callable(callee): return callee(*args)
            raise LupiError('Tentativa de chamar algo que nao e funcao')
        if isinstance(expr, GetAttr):
            obj=self.eval_expr(expr.obj)
            if isinstance(obj, dict) and expr.name in obj: return obj[expr.name]
            if hasattr(obj, expr.name): return getattr(obj, expr.name)
            raise LupiError(f'Atributo nao encontrado: {expr.name}')
        if isinstance(expr, RangeExpr):
            start=self.eval_expr(expr.start); end=self.eval_expr(expr.end)
            if not isinstance(start,int) or not isinstance(end,int): raise LupiError('Ranges exigem inteiros')
            step=1 if end >= start else -1
            return list(range(start, end + step if expr.inclusive else end, step))
        raise LupiError(f'Expressao nao suportada: {expr}')
    def truthy(self, v): return not (v is None or v is False)
    def load_lupi_module(self, module_name):
        if module_name in self.module_cache: return self.module_cache[module_name]
        path = self.module_search_dir / (module_name.replace('.', '/') + '.lp')
        if not path.exists(): raise LupiError(f'Modulo Lupi nao encontrado: {path.name}')
        sub=Interpreter(module_search_dir=str(path.parent)); sub.module_cache=self.module_cache; sub.py_module_cache=self.py_module_cache
        sub.run(Parser(Lexer(path.read_text(encoding='utf-8')).tokenize()).parse())
        mod=LupiModule(module_name,{k:v for k,v in sub.global_env.values.items() if not k.startswith('_')})
        self.module_cache[module_name]=mod; return mod
    def load_py_module(self, module_name):
        if module_name in self.py_module_cache: return self.py_module_cache[module_name]
        try: mod=importlib.import_module(module_name)
        except ImportError as e: raise LupiError(f"Modulo Python '{module_name}' nao encontrado. Se for pacote externo, rode: lupi install {module_name.split('.')[0]}") from e
        self.py_module_cache[module_name]=mod; return mod


def run_lupi_file(path: str):
    p=Path(path)
    if not p.exists(): raise LupiError(f'Arquivo nao encontrado: {path}')
    interp=Interpreter(module_search_dir=str(p.parent))
    interp.run(Parser(Lexer(p.read_text(encoding='utf-8')).tokenize()).parse())


def lupi_install(packages: list[str]):
    cmd=[sys.executable,'-m','pip','install',*packages]
    print('Executando:', ' '.join(cmd))
    rc=subprocess.run(cmd).returncode
    raise SystemExit(rc) if rc != 0 else None
