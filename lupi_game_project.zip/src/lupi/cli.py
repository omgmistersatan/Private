from __future__ import annotations

import argparse
import sys

from . import __version__
from .game_runtime import GameUnavailable
from .runtime import LupiError, lupi_install, run_lupi_file


def build_cli():
    parser = argparse.ArgumentParser(prog='lupi', description='Lupi language CLI')
    sub = parser.add_subparsers(dest='command', required=True)
    p_run = sub.add_parser('run', help='Executa arquivo .lp')
    p_run.add_argument('file')
    p_install = sub.add_parser('install', help='Instala pacotes Python')
    p_install.add_argument('packages', nargs='+')
    sub.add_parser('version', help='Mostra versao')
    return parser


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv and argv[0].endswith('.lp'):
        argv = ['run', *argv]
    parser = build_cli()
    args = parser.parse_args(argv)
    try:
        if args.command == 'run':
            run_lupi_file(args.file)
        elif args.command == 'install':
            lupi_install(args.packages)
        elif args.command == 'version':
            print(f'Lupi v{__version__}')
        else:
            parser.print_help()
    except (LupiError, GameUnavailable) as e:
        print(f'[Erro Lupi] {e}', file=sys.stderr)
        raise SystemExit(1)


if __name__ == '__main__':
    main()
