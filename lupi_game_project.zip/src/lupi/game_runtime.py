from __future__ import annotations

import random
import time as _time
from types import SimpleNamespace


class GameUnavailable(RuntimeError):
    pass


def _load_pygame():
    try:
        import pygame  # type: ignore
        return pygame
    except Exception as e:
        raise GameUnavailable(
            "Modulo 'game' requer pygame-ce. Instale com: lupi install pygame-ce"
        ) from e


COLOR_MAP = {
    "black": (0, 0, 0),
    "white": (255, 255, 255),
    "red": (255, 0, 0),
    "green": (0, 255, 0),
    "blue": (0, 0, 255),
    "yellow": (255, 220, 0),
    "cyan": (0, 255, 255),
    "magenta": (255, 0, 255),
}


def parse_color(value):
    if isinstance(value, (tuple, list)) and len(value) == 3:
        return tuple(int(x) for x in value)
    return COLOR_MAP.get(str(value).lower(), (255, 255, 255))


class SoundWrapper:
    def __init__(self, pygame, path: str):
        self.sound = pygame.mixer.Sound(path)

    def play(self):
        self.sound.play()


class MusicWrapper:
    def __init__(self, pygame, path: str):
        self.pygame = pygame
        self.path = path

    def play(self, loop=False):
        self.pygame.mixer.music.load(self.path)
        self.pygame.mixer.music.play(-1 if loop else 0)


class SpriteWrapper:
    def __init__(self, runtime, path: str, x, y):
        self.runtime = runtime
        self.pygame = runtime.pygame
        self.image = self.pygame.image.load(path).convert_alpha()
        self.x = float(x)
        self.y = float(y)
        self.vx = 0.0
        self.vy = 0.0
        self.rotation = 0.0
        self.scale = 1.0
        self.visible = True
        rect = self.image.get_rect()
        self.w = rect.width
        self.h = rect.height

    def draw(self):
        if not self.visible:
            return
        img = self.image
        if self.scale != 1.0:
            w = max(1, int(self.w * self.scale))
            h = max(1, int(self.h * self.scale))
            img = self.pygame.transform.scale(img, (w, h))
        if self.rotation:
            img = self.pygame.transform.rotate(img, self.rotation)
        self.runtime.screen.blit(img, (self.x, self.y))

    def move(self, dx, dy):
        self.x += dx
        self.y += dy

    def set_pos(self, x, y):
        self.x = x
        self.y = y

    def collides(self, other):
        a = self.pygame.Rect(self.x, self.y, self.w, self.h)
        b = self.pygame.Rect(other.x, other.y, other.w, other.h)
        return a.colliderect(b)


class GameRuntime:
    def __init__(self, interp):
        self.interp = interp
        self._pygame = None
        self.screen = None
        self.clock = None
        self.running = False
        self.bg_color = (0, 0, 0)
        self.last_dt = 0.0
        self.start_time = _time.time()
        self.keys_pressed_once = set()

    @property
    def pygame(self):
        if self._pygame is None:
            self._pygame = _load_pygame()
            self._pygame.init()
            try:
                self._pygame.mixer.init()
            except Exception:
                pass
            self._pygame.font.init()
        return self._pygame

    def window(self, width, height, title):
        pg = self.pygame
        self.screen = pg.display.set_mode((int(width), int(height)))
        pg.display.set_caption(str(title))
        self.clock = pg.time.Clock()

    def set_background(self, color):
        self.bg_color = parse_color(color)

    def clear(self, color=None):
        if self.screen is None:
            raise GameUnavailable("Chame game.window(...) antes de desenhar")
        self.screen.fill(parse_color(self.bg_color if color is None else color))

    def rect(self, x, y, w, h, color):
        self.pygame.draw.rect(self.screen, parse_color(color), self.pygame.Rect(x, y, w, h))

    def circle(self, x, y, radius, color):
        self.pygame.draw.circle(self.screen, parse_color(color), (int(x), int(y)), int(radius))

    def line(self, x1, y1, x2, y2, color, width=1):
        self.pygame.draw.line(self.screen, parse_color(color), (x1, y1), (x2, y2), int(width))

    def text(self, msg, x, y, color="white", size=24):
        font = self.pygame.font.SysFont(None, int(size))
        surface = font.render(str(msg), True, parse_color(color))
        self.screen.blit(surface, (x, y))

    def sprite(self, path, x, y):
        return SpriteWrapper(self, path, x, y)

    def sound(self, path):
        return SoundWrapper(self.pygame, path)

    def music(self, path):
        return MusicWrapper(self.pygame, path)

    def key(self, name):
        keys = self.pygame.key.get_pressed()
        mapping = {
            "left": self.pygame.K_LEFT, "right": self.pygame.K_RIGHT,
            "up": self.pygame.K_UP, "down": self.pygame.K_DOWN,
            "space": self.pygame.K_SPACE, "a": self.pygame.K_a,
            "d": self.pygame.K_d, "w": self.pygame.K_w, "s": self.pygame.K_s,
        }
        code = mapping.get(str(name).lower())
        return bool(code is not None and keys[code])

    def key_pressed(self, name):
        return str(name).lower() in self.keys_pressed_once

    def mouse_pos(self):
        return self.pygame.mouse.get_pos()

    def mouse_down(self, button):
        left, middle, right = self.pygame.mouse.get_pressed(3)
        mapping = {"left": left, "middle": middle, "right": right}
        return bool(mapping.get(str(button).lower(), False))

    def rand(self, a, b):
        return random.randint(int(a), int(b))

    def time(self):
        return _time.time() - self.start_time

    def delta(self):
        return self.last_dt

    def run(self):
        if self.screen is None:
            raise GameUnavailable("Chame game.window(...) antes de game.run()")
        self.running = True
        while self.running:
            self.keys_pressed_once.clear()
            for event in self.pygame.event.get():
                if event.type == self.pygame.QUIT:
                    self.running = False
                elif event.type == self.pygame.KEYDOWN:
                    keyname = self.pygame.key.name(event.key)
                    self.keys_pressed_once.add(keyname)
                    self.call_optional("on_key_press", keyname)
                elif event.type == self.pygame.MOUSEBUTTONDOWN:
                    x, y = event.pos
                    bmap = {1: "left", 2: "middle", 3: "right"}
                    self.call_optional("on_mouse_click", x, y, bmap.get(event.button, str(event.button)))

            self.last_dt = self.clock.tick(60) / 1000.0
            self.call_optional("update", self.last_dt)
            self.call_optional("draw")
            self.pygame.display.flip()
        self.pygame.quit()

    def call_optional(self, name, *args):
        try:
            fn = self.interp.global_env.get(name)
        except Exception:
            return
        if hasattr(fn, "params"):
            return fn(self.interp, list(args))
        if callable(fn):
            return fn(*args)


def game_namespace(interp):
    rt = GameRuntime(interp)
    return SimpleNamespace(
        window=rt.window,
        set_background=rt.set_background,
        clear=rt.clear,
        rect=rt.rect,
        circle=rt.circle,
        line=rt.line,
        text=rt.text,
        sprite=rt.sprite,
        sound=rt.sound,
        music=rt.music,
        key=rt.key,
        key_pressed=rt.key_pressed,
        mouse_pos=rt.mouse_pos,
        mouse_down=rt.mouse_down,
        rand=rt.rand,
        time=rt.time,
        delta=rt.delta,
        run=rt.run,
    )
